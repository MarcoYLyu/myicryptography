# Cryptography Library

This repository contains a library of common cryptography functions, including but not limited to elliptic curves and factoring. See below for more instruction on how to use the library itself.

## Installation

Use `pip3` to install the package

``>>> pip3 install scytale``

## Acknowledge

Every algorithm in this project comes from MATH 116 at UCLA.
